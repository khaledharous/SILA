import os
import sqlite3
import logging
from flask import Flask, render_template, request, redirect, url_for, flash, session, g
import sqlite3
import smtplib
import re
from werkzeug.security import generate_password_hash, check_password_hash
from email.mime.text import MIMEText
from datetime import date, timedelta

logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__, template_folder="SILA/templates", static_folder="SILA/static")
app.secret_key = "your_secret_key"
DATABASE = "users.db"

def create_database():
    db_path = os.path.join(app.root_path, 'users.db')
    if os.path.exists(db_path):
        try:
            sqlite3.connect(db_path).execute('PRAGMA quick_check;')
        except sqlite3.DatabaseError:
            os.remove(db_path)
    with sqlite3.connect(db_path) as conn:
        conn.execute("PRAGMA journal_mode=WAL;")  # Enable WAL mode
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_ST TEXT NOT NULL,
                username TEXT NOT NULL,
                date_of_birth TEXT NOT NULL,
                gender TEXT NOT NULL,
                student_id TEXT UNIQUE NOT NULL,
                field TEXT NOT NULL,
                academic_year TEXT NOT NULL,
                address TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                city TEXT NOT NULL,
                password TEXT NOT NULL
            )
        ''')
        # Add other table creation queries here
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS teachers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone_numbre TEXT NOT NULL,
                email TEXT NOT NULL,
                city TEXT NOT NULL,
                name TEXT NOT NULL,
                Prof_id TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                group_T TEXT NOT NULL,
                faculty TEXT NOT NULL,
                field TEXT NOT NULL,
                date_of_birth TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS announcements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                year TEXT NOT NULL,
                field TEXT NOT NULL,
                group_name TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        cursor.execute('''
             CREATE TABLE IF NOT EXISTS time_slots (
             id INTEGER PRIMARY KEY AUTOINCREMENT,
             Prof_id INTEGER,
             day TEXT,
             time_slot TEXT,
             subject TEXT
            ) 
        ''')    
        cursor.execute('''
             CREATE TABLE IF NOT EXISTS time_slots_students (
             id INTEGER PRIMARY KEY AUTOINCREMENT,
             user_group_ST INTEGER,
             user_field INTEGER,
             user_academic_year INTEGER,
             day TEXT,
             time_slot TEXT,
             subject TEXT
            ) 
        ''')       

        conn.commit()


def get_db():
    if 'db' not in g:
        logging.debug("Opening database connection")
        g.db = sqlite3.connect(DATABASE, timeout=10)
        g.db.execute("PRAGMA journal_mode=WAL;")
        g.db.row_factory = sqlite3.Row
    return g.db




def add_teacher(phone_numbre, email, city, name, Prof_id, group_T, faculty, field, date_of_birth, raw_password):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO teachers (phone_numbre, email, city, name, Prof_id, group_T, faculty, field,  date_of_birth, password)
        VALUES (?, ?,  ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (phone_numbre, email, city, name, Prof_id, group_T, faculty, field,  date_of_birth, raw_password))
    conn.commit()
    



@app.route('/login_teacher', methods=['GET', 'POST'])
def login_teacher():
    if request.method == 'POST':
        Prof_id = request.form.get("Prof_id", "").strip()
        password = request.form.get("password", "").strip()

        conn = sqlite3.connect("users.db")
        cursor = conn.cursor()
        cursor.execute("SELECT Prof_id, name, password FROM teachers WHERE Prof_id = ?", (Prof_id,))
        teacher = cursor.fetchone()
        conn.close()

        if teacher and teacher[2] == password:
            session['Prof_id'] = teacher[0]
            session['teacher_name'] = teacher[1]
            return redirect(url_for('profile_teacher'))
        else:
            flash("Prof_id ou mot de passe incorrect", "error")
            return redirect(url_for('login_teacher'))
   
    return render_template('enseignant/login_teacher.html')


@app.route('/profile_teacher')
def profile_teacher():
    if 'Prof_id' not in session:
        flash("Plaese Login first ", "error")
        return redirect(url_for('login_teacher'))

    Prof_id = session['Prof_id']
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM teachers WHERE Prof_id = ?", (Prof_id,))
    teacher = cursor.fetchone()
    conn.close()

    if teacher:
        teacher_data = {
            'id': teacher[0],
            'phone_numbre': teacher[1],
            'email': teacher[2],
            'city': teacher[3],
            'name': teacher[4],
            'Prof_id': teacher[5],
            'password': teacher[6],
            'group_T': teacher[7],
            'faculty': teacher[8],
            'field': teacher[9],
            'date_of_birth': teacher[10]
        }
        return render_template('enseignant/profile_teacher.html', teacher=teacher_data)
    else:
        flash("Teacher Not Found !", "error")
        return redirect(url_for('login_teacher'))
    
@app.route("/disconnect")
def disconnect():
    if "Prof_id" in session and request.referrer:
        session.clear()
        flash("You have been logged out.", "success")
        return redirect(url_for("login_teacher"))
    else:
        flash("Login in first", "error")
        return redirect(url_for("login_teacher"))
    


@app.route('/register', methods=['POST'])
def register():
    group_ST = ''
    username = request.form.get('username', '')
    date_of_birth = request.form.get('dateofbirth', '')
    gender = request.form.get('gender', '')
    student_id = request.form.get('studentid', '').strip()
    field = request.form.get('field', '')
    academic_year = request.form.get('academic_year', '')
    address = request.form.get('address', '')
    email = request.form.get('email', '').strip()
    city = request.form.get('city', '')
    password = request.form.get('password', '')
    confirm_password = request.form.get('confirm-password', '')

    if not re.match(r"^\d{12}$", student_id):
        flash("Error: Student ID must be between 12 digits and contain only numbers!", "error")
        return redirect(url_for('person'))

    if not re.match(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", email):
        flash("Invalid email format!", "error")
        return redirect(url_for('person'))

    if password != confirm_password:
        flash("Error: Passwords do not match!", "error")
        return redirect(url_for('person'))

    if len(password) < 8:
        flash("Error: Password must be at least 8 characters long!", "error")
        return redirect(url_for('person'))

    hashed_password = generate_password_hash(password)
    
    try:
        with get_db() as conn:
            cursor = conn.cursor()

            if cursor.execute("SELECT 1 FROM users WHERE student_id = ?", (student_id,)).fetchone():
                flash("Student ID already exists!", "error")
                return redirect(url_for('person'))

            if cursor.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
                flash("Email already exists!", "error")
                return redirect(url_for('person'))

            cursor.execute("""
                INSERT INTO users (group_ST, username, date_of_birth, gender, student_id, field,
                academic_year, address, email, city, password)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                group_ST, username, date_of_birth, gender, student_id, field,
                academic_year, address, email, city, hashed_password
            ))

            conn.commit()
    except sqlite3.OperationalError as e:
        flash(f"Database error: {e}", "error")
        return redirect(url_for('person'))


    flash("Registration successful! Please sign in.", "success")
    return redirect(url_for('login'))


# Login Route
def get_db():
    if 'db' not in g:
        logging.debug("Opening database connection")
        db = sqlite3.connect(os.path.join(app.root_path, 'users.db'), timeout=5)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA journal_mode=WAL;')
        g.db = db
    return g.db


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form["password"].strip()

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()

        if user and check_password_hash(user["password"], password):
            session["user"] = {
                "id":            user["id"],
                "group_ST":    user["group_ST"],
                "username":      user["username"],
                "date_of_birth": user["date_of_birth"],
                "gender":        user["gender"],
                "student_id":    user["student_id"],
                "field":         user["field"],          # تأكد هذا العمود موجود فعلاً في الجدول
                "academic_year": user["academic_year"],
                "address":       user["address"],
                "email":         user["email"],
                "city":          user["city"]
            }
            flash("Login successful!", "success")
            return redirect(url_for("profile"))
        else:
            flash("Invalid username or password.", "error")
            return redirect(url_for("login"))
    return render_template("login.html")
   


# Profile Route
@app.route("/profile")
def profile():
    if "user" not in session:
        flash("Please log in first!", "error")
        return redirect(url_for("login"))
    
    # Retrieve user data from session
    user_data = session["user"]
    return render_template("profile.html", user=user_data)

@app.route("/logout")
def logout():
    if "user" in session and request.referrer:
        # تأكد أنو جاي من رابط حقيقي داخل الموقع
        session.clear()
        flash("You have been logged out.", "success")
        return redirect(url_for("login"))


    

@app.route('/advertisements_teacher', methods=['GET', 'POST'])
def advertisements_teacher():
    if request.method == 'POST':
        year = request.form['year']
        field = request.form['field']
        group_name = request.form['group_name']
        message = request.form['message']

        conn = get_db()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO announcements (year, field, group_name, message) VALUES (?, ?, ?, ?)",
            (year, field, group_name, message)
        )
        conn.commit()

        flash(' The Advertisement Sent Successfully  ', 'success')
        return redirect(url_for('advertisements_teacher'))

    return render_template('enseignant/advertisements_teacher.html')  # Redirect to avoid form resubmission
    
    

@app.route('/annonce_student')
def annonce_student():
    if "user" not in session:
        flash("Please log in first", "error")
        return redirect(url_for("login"))
    
    academic_year = session["user"]["academic_year"]
    field = session["user"]["field"]
    group_ST = session["user"]["group_ST"]

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM announcements WHERE year = ? AND field =?  AND group_name = ? ORDER BY created_at DESC", (academic_year, field, group_ST))
    annonces = cursor.fetchall()

    return render_template('etudiant/annonce_student.html', announcements=annonces) 

@app.route('/time_teacher')
def time_teacher():
    Prof_id = session.get("Prof_id")
    if not Prof_id:
        return redirect(url_for('login_teacher'))  # إذا ما كان فيه ID، تروح لصفحة تسجيل الدخول

    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()

    cursor.execute("SELECT day, time_slot, subject FROM time_slots WHERE Prof_id = ?", (Prof_id,))
    rows = cursor.fetchall()
    conn.close()

    # نحول البيانات لقاموس: day -> {time_slot: subject}
    schedule = {}
    for day, slot, subject in rows:
        if day not in schedule:
            schedule[day] = {}
        schedule[day][slot] = subject

    return render_template("enseignant/time_teacher.html", schedule=schedule)

@app.route('/time')
def time():
    user = session.get("user")
    if not user:
        return redirect(url_for('login'))  # إذا الجلسة غير موجودة، رجع للوجين

    user_group_ST = user["group_ST"]  # نستعمل student_id مش id
    user_field = user["field"]
    user_academic_year = user["academic_year"] 

    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()

    cursor.execute("SELECT day, time_slot, subject FROM time_slots_students WHERE user_group_ST = ? AND user_field = ? AND user_academic_year = ?", (user_group_ST, user_field, user_academic_year))
    rows = cursor.fetchall()
    conn.close()

    schedule = {}
    for day, slot, subject in rows:
        if day not in schedule:
            schedule[day] = {}
        schedule[day][slot] = subject

    return render_template("etudiant/time.html", schedule=schedule)


# Forgot Password Route

@app.route("/forgotpassword", methods=["GET", "POST"]) 
def forgot_password():
    if request.method == "POST":
        email = request.form["email"].strip()
        if email_exists(email):
            if send_reset_email(email):flash("A password reset link has been sent to your email.", "success")
            else:
                flash("Failed to send email. Try again later.", "error")
        else:
            flash("Email not found in the system.", "error")
    return render_template("forgotpassword.html")

# Reset Password Route
@app.route("/resetpassword", methods=["GET", "POST"])
def reset_password():
    email = request.args.get("email","")
    if request.method == "POST":
        new_password = request.form["new_password"]
        hashed_password = generate_password_hash(new_password)
        conn = sqlite3.connect("users.db")
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET password = ? WHERE email = ?", (hashed_password, email))
        conn.commit()
        conn.close()
        flash("Your password has been updated!", "success")
        return redirect(url_for("login"))
    return render_template("resetpassword.html", email=email)

# Helper Functions
def send_reset_email(user_email):
    reset_link = f"http://127.0.0.1:5000/resetpassword?email={user_email}"
    subject = "Password Reset Request"
    body = f"Click the link below to reset your password:\n\n{reset_link}"

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = "your_email@yandex.com"
    msg["To"] = user_email

    try:
        server = smtplib.SMTP("smtp.yandex.com", 587)
        server.starttls()
        server.login("your_email@yandex.com", "your_email_password")
        server.sendmail("your_email@yandex.com", user_email, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False

def email_exists(email):
    with sqlite3.connect("users.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
        user = cursor.fetchone()
    return user is not None

# Home Route
@app.route("/")
def home():
    return redirect(url_for("index"))  # Redirect to index

@app.route("/index")
def index():
    return render_template("index.html")

@app.route("/person")
def person():
    return render_template("person.html")

@app.route("/etablisement")
def etablisement():
    if "user" not in session:
        flash("Please log in first!", "error")
        return redirect(url_for("login"))
    return render_template("etablisement.html")

@app.route("/notes")
def notes():
    if "user" not in session:  # Check if the user is not logged in
        flash("Please log in first!", "error")
        return redirect(url_for("login"))  # Redirect to the login page
    return render_template("notes.html")  # Render the Notes page if logged in

@app.route("/annanceEN")
def annanceEN():
    if "user" not in session:
        flash("Please log in first!", "error")
        return redirect(url_for("login"))
    return render_template("enseignant/annanceEN.html")

@app.route("/etablisementEN")
def etablisementEN():
    if "user" not in session:
        flash("Please log in first!", "error")
        return redirect(url_for("login"))
    return render_template("enseignant/etablisementEN.html")

@app.route("/notesEN")
def notesEN():
    if "user" not in session:
        flash("Please log in first!", "error")
        return redirect(url_for("login"))
    return render_template("enseignant/notesEN.html")

@app.route("/list")
def list():
    if "user" not in session:
        flash("Please log in first!", "error")
        return redirect(url_for("login"))
    return render_template("enseignant/list.html")

@app.route("/years")
def years():
    if "user" not in session:
        flash("Please log in first!", "error")
        return redirect(url_for("login"))
    return render_template("enseignant/years.html")


    
@app.route("/moudule")
def moudule():
    if "user" not in session:
        flash("Please log in first!", "error")
        return redirect(url_for("login"))
    return render_template("etudiant/moudule.html")

@app.route("/noteET")
def noteET():
    if "user" not in session:
        flash("Please log in first!", "error")
        return redirect(url_for("login"))
    return render_template("etudiant/noteET.html")

@app.route("/qr_code")
def qr_code():
    if "user" not in session:
        flash("Please log in first!", "error")
        return redirect(url_for("login"))
    return render_template("etudiant/qr_code.html")


@app.route("/home_student")
def home_student():
    return render_template("etudiant/home_student.html")


@app.route("/home_teacher")
def home_teacher():
    return render_template("enseignant/home_teacher.html")


@app.route("/absence")
def absence():
    return render_template("enseignant/absence.html")

@app.route("/QRCode_teacher")
def QRCode_teacher():
    return render_template("enseignant/QRCode_teacher.html")




@app.route("/advertisements_student")
def advertisements_student():
    return render_template("etudiant/advertisements_student.html")

if __name__ == "__main__":
    create_database()
    app.run(debug=True)  # Disable debug mode in production